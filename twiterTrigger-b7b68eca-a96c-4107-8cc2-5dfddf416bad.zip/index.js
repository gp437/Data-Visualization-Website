console.log('Loading function');
let myText;
exports.handler = async (event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    for (const record of event.Records) {
        // console.log(record.eventID);
        // console.log(record.eventName);
        // console.log('DynamoDB Record: %j', record.dynamodb);
        myText= record.dynamodb.NewImage.text.S;
    }
    return `Successfully processed ${event.Records.length} records.`;
};

let AWS = require("aws-sdk");
let comprehend = new AWS.Comprehend();


let params = {
    LanguageCode: "en",
    Text: myText
};
console.log("params text " + params.Text);
//Create instance of Comprehend
//Function that will be called
exports.handler = (event) => {
    //Call comprehend to detect sentiment of text
    comprehend.detectSentiment(params, (err, data) => {
        //Log result or error
        if (err) {
            console.log("\nError with call to Comprehend:\n" + JSON.stringify(err));
        }
        else {
            console.log("\nSuccessful call to Comprehend:\n" + JSON.stringify(data));
        }
    });
};
