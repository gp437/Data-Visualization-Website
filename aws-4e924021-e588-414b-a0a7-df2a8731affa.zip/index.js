//Import external library with websocket functions
let ws = require('websocket');

//Hard coded domain name and stage - use when pushing messages from server to client
let domainName = "vfvnoa39we.execute-api.us-east-1.amazonaws.com";
let stage = "dev";




let boroughX = ["Barking & Dagenham", "Barnet", "Bexley", "Brent", "City of London"];
let boroughY;

var AWS = require("aws-sdk");
AWS.config.update({
    region: "us-east-1",
    endpoint: "https://dynamodb.us-east-1.amazonaws.com"
});
//Create new DocumentClient
var documentClient = new AWS.DynamoDB.DocumentClient();
var NumericalData = [];



let GETDATA = async () => {
            for (let x = 1450; x < 1475; x++) {
        let id = x;
        // end id
        for (let y = 0; y < 6; y++) {
            boroughY = boroughX[y - 1];

            //Table name and data for table
            var params = {
                TableName: "HousesAverage",
                Key: {
                    id: id,
                    borough: boroughY
                }
            };
            //Retrieve data item from DynamoDB and handle errors
            documentClient.get(params, function (err, data) {
                if (err) {
                    console.error("Unable to read item");
                    // console.error("Error JSON:", JSON.stringify(err));
                }
                else {
                    if (data.Item != undefined) {
                        // console.log("Able to read item + defined");
                        NumericalData.push(data.Item.borough, data.Item.price, data.Item.date);
                        // console.log(NumericalData);
                    }

                }
            });
        }
        //for1
    }
    //for2
    if (NumericalData.length > 0){
        
    return;
    }
};


GETDATA();















setTimeout(function () { let xas= "asd"; }, 500);




exports.handler = async (event) => {
    // try {
        // if(NumericalData.length > 5){
        //Get Message from event
        // const msg = JSON.parse(event.body).data;
        const msg =  JSON.stringify(NumericalData);
        console.log("Message: " + msg);

        //Allocate domain name and stage dynamically
        domainName = event.requestContext.domainName;
        stage = event.requestContext.stage;
        console.log("Domain: " + domainName + " stage: " + stage);

        //Get promises message to connected clients
        let sendMsgPromises = await ws.getSendMessagePromises(msg, domainName, stage);

        //Execute promises
        await Promise.all(sendMsgPromises);
        // }
    // }
    // catch(err){
        
        // return { statusCode: 500, body: "Error: " + JSON.stringify(err) };
    // }
    //Success
    return { statusCode: 200, body: "Data sent successfully." };
};


