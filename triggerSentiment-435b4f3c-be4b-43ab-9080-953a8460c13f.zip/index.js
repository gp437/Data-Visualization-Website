console.log('Loading function');
let AWS = require("aws-sdk");
let comprehend = new AWS.Comprehend();
      
exports.handler = (event) => {
   let textS;
   let id;
   let borough;
       for (const record of event.Records) {
        // console.log(record.eventID);
        // console.log(record.eventName);
          textS = record.text.S;
          id = record.id.N;
          borough = record.borough.S;
    }
           let  params = {
    LanguageCode: "en",//Possible values include: "en", "es", "fr", "de", "it", "pt"
    Text: textS
};
let sentiment;
let sentimentPositive;
let sentimentNegative;
let sentimentMixed;
let sentimentNeutral;
    comprehend.detectSentiment(params, (err, data) => {
        //Log result or error
        if (err) {
            console.log("\nError with call to Comprehend:\n" + JSON.stringify(err));
        }
        else {
            console.log("\nSuccessful call to Comprehend:\n" + JSON.stringify(data));
            sentiment = data.Sentiment;
            sentimentPositive = data.SentimentScore.Positive;
            sentimentNegative = data.SentimentScore.Negative;
            sentimentMixed = data.SentimentScore.Mixed;
            sentimentNeutral = data.SentimentScore.Neutral;
            addSentiment();
        }
    });
                // console.log("sentiment " + sentiment);
    // database upload result
    // Create new DocumentClient
let documentClient = new AWS.DynamoDB.DocumentClient();

//Returns all of the connection IDs


//Deletes the specified connection ID
let addSentiment = async () => {
var params = {
  TableName: 'SentimentTable',
  Item: {
    'id' : id,
    'sentiment' :  sentiment,
    'borough' : borough,
    'sentimentPositive' : sentimentPositive,
    'sentimentNegative' : sentimentNegative,
    'sentimentMixed' : sentimentMixed,
    'sentimentNeutral' : sentimentNeutral
  }
};
    return documentClient.put(params).promise();
};
// end database

     };
    