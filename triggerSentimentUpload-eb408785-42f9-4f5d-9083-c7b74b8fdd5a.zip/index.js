let textS = "good house";
let AWS = require("aws-sdk");
let positiveText;
let comprehend = new AWS.Comprehend();
let params;
exports.handler = async (event, context) => {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    for (const record of event.Records) {
         textS = record.text.S;
        //  console.log(record.text.S);
        // console.log(record.borough.S);
        // boroughS = record.borough.S;
        // console.log("id " + record.id.N);
        // idN = record.id.N;
        // console.log('DynamoDB Record: %j', record.dynamodb);
        positiveText = textS;
TrigComprehend();
    }
    
};  

function TrigComprehend (){
          params = {
    LanguageCode: "en",//Possible values include: "en", "es", "fr", "de", "it", "pt"
    Text: positiveText
};
console.log(textS);

    comprehend.detectSentiment(params, (err, data) => {
        //Log result or error
        if (err) {
            console.log("\nError with call to Comprehend:\n" + JSON.stringify(err));
        }
        else {
            console.log("\nSuccessful call to Comprehend:\n" + JSON.stringify(data));
        }
    });  
}

